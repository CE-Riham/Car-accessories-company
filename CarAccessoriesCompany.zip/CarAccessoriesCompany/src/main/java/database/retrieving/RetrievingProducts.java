package database.retrieving;

import classes.Starter;
import helpers.Generator;
import model.InstallReq;
import model.Product;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class RetrievingProducts {
    private Connection con;
    private String status;

    public RetrievingProducts(Connection con) {
        this.con = con;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    public List<InstallReq> selectInstallersWithCondition(String username) {
        List<InstallReq> installRequestList = new ArrayList<>();

        try (PreparedStatement preparedStatement = con.prepareStatement("SELECT username, preferredDate, carMakeModel, productId, requestId FROM installationrequests WHERE username = ?")) {
            preparedStatement.setString(1, username);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    LocalDate preferredDate = resultSet.getDate("preferredDate").toLocalDate();
                    String carMakeModel = resultSet.getString("carMakeModel");
                    int productId = resultSet.getInt("productId");
                    int requestId = resultSet.getInt("requestId");

                    InstallReq installRequest = new InstallReq(username, preferredDate, carMakeModel, productId, requestId);

                    installRequestList.add(installRequest);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return installRequestList;
    }






    public List<Product> selectOrdersWithCondition(String sql, Object... params) {
        List<Product> productList = new ArrayList<>();

        try (PreparedStatement preparedStatement = con.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                preparedStatement.setObject(i + 1, params[i]);
            }

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    int productId = resultSet.getInt("productId");
                    int availableAmount = resultSet.getInt("availability");
                    int numberOfOrders = resultSet.getInt("numberOfOrders");
                    double productPrice = resultSet.getDouble("price");
                    String productName = resultSet.getString("productName");
                    String longDescription = resultSet.getString("longDescription");
                    String shortDescription = resultSet.getString("shortDescription");
                    String imagePath = resultSet.getString("image");
                    String productCategory = resultSet.getString("category");

                    Product product = new Product(productId, availableAmount, numberOfOrders, productPrice,
                            productName, longDescription, shortDescription, imagePath, productCategory);

                    productList.add(product);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return productList;
    }


    public List<Product> selectProductsWithCondition(String condition) {
        List<Product> products = new ArrayList<>();
        Statement st = null;
        try {
            String query = "SELECT * FROM products " + condition;
            st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs != null && rs.next())
                products.add(Generator.rsToProduct(rs));
            setStatus("Retrieving products successfully");
            return products;
        } catch (Exception e) {
            setStatus("Error while retrieving products from database");
            return new ArrayList<>();
        } finally {
            try {
                if (st != null) st.close();
            } catch (Exception e) {
                Starter.logger.warning("can't close statement");
            }
        }
    }

    public List<Product> selectAllProducts() {
        return selectProductsWithCondition(";");
    }

    public List<Product> selectFromProductsTable(String field, String input) {
        return selectProductsWithCondition("where " + field + " = \'" + input + "\';");
    }

    public List<Product> findProductsByID(String id) {
        return selectFromProductsTable("productID", id);
    }

    public List<Product> findProductsByProductName(String productName) {
        return selectFromProductsTable("productName", productName);
    }

    public List<Product> findProductsByCategory(String category) {
        return selectFromProductsTable("category", category);
    }

    public List<Product> selectOrdersWithCondition(String condition) {
        List<Product> products = new ArrayList<>();
        Statement st = null;
        try {
            String query = "SELECT * FROM orders " + condition;
            st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs != null && rs.next())
                products.add(Generator.rsToProduct(rs));
            setStatus("Retrieving products successfully");
            return products;
        } catch (Exception e) {
            setStatus("Error while retrieving products from database");
            return new ArrayList<>();
        } finally {
            try {
                if (st != null) st.close();
            } catch (Exception e) {
                Starter.logger.warning("can't close statement");
            }
        }
    }
}