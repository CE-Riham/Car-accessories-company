package model;

import java.sql.Connection;
import java.time.LocalDate;

public class InstallReq {
    private String username;
    private LocalDate preferredDate;
    private String carMakeModel;
    private int productId;
    private int requestId;

    // Constructors
    public InstallReq() {
    }

    public InstallReq(String username, LocalDate preferredDate, String carMakeModel, int productId, int requestId) {
        this.username = username;
        this.preferredDate = preferredDate;
        this.carMakeModel = carMakeModel;
        this.productId = productId;
        this.requestId = requestId;
    }

    // Getters and setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public LocalDate getPreferredDate() {
        return preferredDate;
    }

    public void setPreferredDate(LocalDate preferredDate) {
        this.preferredDate = preferredDate;
    }

    public String getCarMakeModel() {
        return carMakeModel;
    }

    public void setCarMakeModel(String carMakeModel) {
        this.carMakeModel = carMakeModel;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getRequestId() {
        return requestId;
    }

    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }

    @Override
    public String toString() {
        return "installationrequests{" +
                "username='" + username + '\'' +
                ", preferredDate=" + preferredDate +
                ", carMakeModel='" + carMakeModel + '\'' +
                ", productId=" + productId +
                ", requestId=" + requestId +
                '}';
    }
}
