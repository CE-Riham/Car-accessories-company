package controllers;

import classes.DBConnector;
import classes.Mail;
import classes.UserSession;
import authentication.Register;
import database.inserting.InsertingData;
import database.updating.UserUpdater;
import helpers.Uploader;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.InstallReq;


import javax.mail.MessagingException;
import java.sql.*;
import java.time.LocalDate;

public class HomePage {
    private InstallReq request;
    private InsertingData reqInserter;
    private UserUpdater dataUpdater;
    private Uploader uploader;
    Register reg;
    public HomePage()
    {
        uploader = new Uploader();
        dataUpdater = new UserUpdater(DBConnector.getConnector().getCon());
    }
    private String status;
    public void setStatus(String status) {
        this.status = status;
    }
    public String getStatus() {
        return status;
    }

    public HomePage(Connection connection){
        reqInserter = new InsertingData(connection);
    }
    @FXML
    private TextField carMakeModelField;

    @FXML
    private TextField searchField;

    @FXML
    private ComboBox<?> categoryComboBox;

    @FXML
    private TextArea productTextArea;
    @FXML
    private DatePicker preferredDateField;
    @FXML
    private Button orderBtt;

    private static final String JDBC_URL = "jdbc:mysql://localhost:3307/mysql";
    @FXML
    void ordrerReq(ActionEvent event) throws  SQLException, MessagingException {
        String selectedProduct = productTextArea.getSelectedText();
        String[] productInfo = selectedProduct.split("\n");

        int userId = Integer.parseInt(UserSession.getSessionId());
        int productId = Integer.parseInt(productInfo[0].split(":")[1].trim());
        insertOrderIntoDatabase(userId, productId);

        try (Connection connection = DriverManager.getConnection(JDBC_URL, "root", pass)) {
            String query = "SELECT email FROM users_new WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, userId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        String userEmail = resultSet.getString("email");
                        Mail m = new Mail();
                        m.rasheedEmail(userEmail); // Use userEmail instead of resultSet.getString(1)
                    }
                    else {
                        setStatus("Insert Request was Inserting successfully");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private void insertOrderIntoDatabase(int userId, int productId) {
        String insertQuery = "INSERT INTO Orders (user_id, product_id, order_date) VALUES (?, ?, ?)";

        try (
                Connection connection = DriverManager.getConnection(JDBC_URL, "root", pass);
                PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)
        ) {
            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, productId);
            Timestamp orderDate = new Timestamp(System.currentTimeMillis());
            preparedStatement.setTimestamp(3, orderDate);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    String pass = "Vqo@954719";

    @FXML
    void showProducts(ActionEvent event) {
        String searchText = searchField.getText();
        String selectedCategory = (String) categoryComboBox.getValue();

        StringBuilder resultText = new StringBuilder();

        try (Connection connection = DriverManager.getConnection(JDBC_URL, "root", pass)) {
            String sql;
            if (searchText == null || searchText.trim().isEmpty()) {
                sql = "SELECT * FROM Product WHERE Category = ?";
            } else {
                sql = "SELECT * FROM Product WHERE Category = ? AND (Name LIKE ? OR Description LIKE ?)";
            }

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, selectedCategory);
                if (searchText != null && !searchText.trim().isEmpty()) {
                    preparedStatement.setString(2, "%" + searchText + "%");  // Search by name
                    preparedStatement.setString(3, "%" + searchText + "%");  // Search by description
                }
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        int productId = resultSet.getInt("ProductId");
                        String name = resultSet.getString("Name");
                        String description = resultSet.getString("Description");
                        double price = resultSet.getDouble("Price");
                        boolean availability = resultSet.getBoolean("Availability");
                        resultText.append(String.format("""
        Product ID: %d
        Name: %s
        Description: %s
        Price: %.2f
        Availability: %b

        """, productId, name, description, price, availability));

                    }
                    productTextArea.setText(resultText.toString());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }


    @FXML
    void insertInstallationRequest(ActionEvent event) {
        String selectedProduct = productTextArea.getSelectedText();

        if (selectedProduct == null || selectedProduct.isEmpty()) {
            showAlert("Please select a product.");
            return;
        }

        String[] productInfo = selectedProduct.split("\n");

        if (productInfo.length < 2) {
            showAlert("Invalid product information.");
            return;
        }


        try {
            int userId = Integer.parseInt(UserSession.getSessionId());
            int productId = Integer.parseInt(productInfo[0].split(":")[1].trim());

            String carMakeModel = carMakeModelField.getText();
            LocalDate preferredDate = preferredDateField.getValue();
            request = new InstallReq(userId, productId, Integer.parseInt(carMakeModel), preferredDate);
            request.toString();
            insertInstallationRequestToDatabase(request);
            showAlert("Installation request successfully inserted!");
        } catch (NumberFormatException | NullPointerException | ArrayIndexOutOfBoundsException e) {
            showAlert("Error parsing input. Please check your input.");
            e.printStackTrace(); // Log the exception for debugging   purposes
        } catch (Exception e) {
            showAlert("An error occurred while inserting the installation request.");
            e.printStackTrace(); // Log the exception for debugging purposes
        }
    }


    private void insertInstallationRequestToDatabase(InstallReq req) {

        if(reqInserter.insertInstallReq(req)) {
            setStatus("Insert Request was Inserting successfully");
        }
        else {
            setStatus("Couldn't Insert Request");

        }


    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Installation Request");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
