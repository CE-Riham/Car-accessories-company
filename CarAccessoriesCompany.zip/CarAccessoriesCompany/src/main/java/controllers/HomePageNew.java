package controllers;

import cards.ProductCard;
import classes.DBConnector;
import classes.UserSession;
import database.retrieving.RetrievingProducts;
import helpers.stage_helpers.AdminStageHelper;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import model.Product;

import java.net.URL;
import java.sql.*;
import java.util.List;
import java.util.ResourceBundle;

public class HomePageNew {
    private List<Product> allProducts;
    private int pageNumber = 0;

    @FXML
    private ComboBox<?> categoryComboBox;

    @FXML
    private Button nextButton;

    @FXML
    private Button prevButton;

    @FXML
    private HBox row1;

    @FXML
    private HBox row2;

    @FXML
    private HBox row21;

    @FXML
    private TextField searchField;

    @FXML
    void onInstallersClick(ActionEvent event) {
        AdminStageHelper.showUserInstaller(event);

    }

    @FXML
    void onLogoutClick(ActionEvent event) {
        UserSession.logoutUser(event);
    }

    @FXML
    void onNextButtonClick(ActionEvent event) {
        pageNumber++;
        fillProducts();
    }

    @FXML
    void onNotificationsCLick(ActionEvent event) {
AdminStageHelper.showUserProfile(event);
    }

    @FXML
    void onOrdersClick(ActionEvent event) {
        AdminStageHelper.showUserOrder(event);
    }

    @FXML
    void onPrevButtonClick(ActionEvent event) {
        pageNumber--;
        fillProducts();
    }

    @FXML
    void onUserProfileClick(ActionEvent event) {
        AdminStageHelper.showUserProfile(event);

    }
    String pass = "Vqo@954719";
    private static final String JDBC_URL = "jdbc:mysql://localhost:3307/mysql";

    @FXML
    void showProducts(ActionEvent event) {
        String searchText = searchField.getText();
        String selectedCategory = (String) categoryComboBox.getValue();
        RetrievingProducts productsRetriever = new RetrievingProducts(DBConnector.getConnector().getCon());

        try (Connection connection = DriverManager.getConnection(JDBC_URL, "root", pass)) {
            String sql;
            if (searchText == null || searchText.trim().isEmpty()) {
                sql = "SELECT * FROM products WHERE Category = ?";
                allProducts = productsRetriever.selectOrdersWithCondition(sql, selectedCategory);

            } else {
                sql = "SELECT * FROM products WHERE category = ? AND (productName LIKE ? OR longDescription LIKE ?)";
                allProducts = productsRetriever.selectOrdersWithCondition(sql, selectedCategory, "%" + searchText + "%", "%" + searchText + "%");

            }

            fillRow1(pageNumber * 12);
            fillRow2(pageNumber * 12 + 6);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void initialize(URL url, ResourceBundle resourceBundle) {
        //activateMenuButton();
        fillProducts();
    }

    private void getAllProductsFromDB() {
        RetrievingProducts productsRetriever = new RetrievingProducts(DBConnector.getConnector().getCon());
        allProducts = productsRetriever.selectOrdersWithCondition("");
    }

    private void fillRow1(int index) {
        row1.getChildren().clear();
        for (int i = index; i < (index + 6) && i < allProducts.size(); i++) {
            row1.getChildren().add(new ProductCard(allProducts.get(i)).getCard());
        }
        disableButton(prevButton, (index == 0));
    }

    private void fillRow2(int index) {
        row2.getChildren().clear();
        for (int i = index; i < (index + 6) && i < allProducts.size(); i++) {
            row2.getChildren().add(new ProductCard(allProducts.get(i)).getCard());
        }
        disableButton(nextButton, ((index + 6) >= allProducts.size()));
    }

    private void fillProducts() {
        getAllProductsFromDB();
        fillRow1(pageNumber * 12);
        fillRow2(pageNumber * 12 + 6);
    }

    private void disableButton(Button button, boolean flag) {
        button.setDisable(flag);
    }

}
